import { env } from 'cloudflare:workers';
export function database(){if(!env.DB)throw new Error('保存サービスを利用できません');return env.DB;}
